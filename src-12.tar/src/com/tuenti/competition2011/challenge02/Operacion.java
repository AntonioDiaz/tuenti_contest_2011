package com.tuenti.competition2011.challenge02;

public class Operacion {

	public Operacion (String linea){
		
	}
	
	public Integer resultado(){
		return -1;
	}
	
}
