package com.tuenti.competition2011.challenge10;

import java.util.Arrays;

import junit.framework.TestCase;


public class Challenge10Test extends TestCase{


	public void testCheckLamps01(){
		
	}

}
