package com.tuenti.competition2011.challenge10;


/**
 * Ejercicio 10 del Tuenti Programming Challenge 2011.
 * @author adiaz
 *
 */
public class Challenge10 {
	
	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		String prueba = "";
		System.out.println(prueba.hashCode());
		String digo ="";
		System.out.println(digo.hashCode());
	
	}
	
	
}
